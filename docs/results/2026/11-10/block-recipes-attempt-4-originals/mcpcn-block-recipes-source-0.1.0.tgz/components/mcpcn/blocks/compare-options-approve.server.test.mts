import test from "node:test";
import { exerciseBlockFixture } from "./compare-options-approve.fixture.mjs";
test("compare-options-approve persists reviewed changes through the real SDK and SQLite", async () => { await exerciseBlockFixture("compare-options-approve"); });
