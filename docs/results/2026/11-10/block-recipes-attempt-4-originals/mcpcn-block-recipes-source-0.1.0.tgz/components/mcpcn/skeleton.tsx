"use client";
export { Skeleton } from "./_mcpcn/components";
