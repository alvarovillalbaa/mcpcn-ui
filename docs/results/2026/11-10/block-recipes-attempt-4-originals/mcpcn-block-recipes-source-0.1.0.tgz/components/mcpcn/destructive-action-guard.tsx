"use client";
export { DestructiveActionGuard } from "./_mcpcn/components";
