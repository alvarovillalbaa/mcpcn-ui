import test from "node:test";
import { exerciseBlockFixture } from "./approval-gated-tool-call.fixture.mjs";
test("approval-gated-tool-call persists reviewed changes through the real SDK and SQLite", async () => { await exerciseBlockFixture("approval-gated-tool-call"); });
