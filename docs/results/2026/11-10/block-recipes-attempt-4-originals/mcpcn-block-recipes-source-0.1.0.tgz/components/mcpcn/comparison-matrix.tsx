"use client";
export { ComparisonMatrix } from "./_mcpcn/components";
