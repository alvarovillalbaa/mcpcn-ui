import test from "node:test";
import { exerciseBlockFixture } from "./extract-review-save.fixture.mjs";
test("extract-review-save persists reviewed changes through the real SDK and SQLite", async () => { await exerciseBlockFixture("extract-review-save"); });
