"use client";
export { ScoreBreakdown } from "./_mcpcn/components";
