import test from "node:test";
import { exerciseBlockFixture } from "./agent-generated-report-review.fixture.mjs";
test("agent-generated-report-review persists reviewed changes through the real SDK and SQLite", async () => { await exerciseBlockFixture("agent-generated-report-review"); });
