# ExtractReviewSave

This editable block includes the controlled UI, bound ExtractReviewSaveApp, Zod state/input/result schemas, real four-tool MCP registration, authored disposable SQL fixtures and a runnable SDK/SQLite test.

## Run the server check

Requires Node 24.22.2 or a compatible Node24 release with node:sqlite, TypeScript5.9, @types/node24, React19, Zod4.4 and the pinned SDK1.30/ext-apps1.7.5 dependencies. The CLI prints dependency commands; it never installs or runs this code. Server-only sources use .mts and explicit .mjs imports so emitted Node modules do not depend on the consumer package type. From this directory:

```sh
npx tsc --strict --target ES2022 --module ESNext --moduleResolution Bundler --lib ES2022,DOM,DOM.Iterable --jsx react-jsx --esModuleInterop --types node --rootDir .. --outDir .mcpcn-block-check extract-review-save.server.test.mts
node --test .mcpcn-block-check/blocks/extract-review-save.server.test.mjs
```

The explicit rootDir keeps the test output path the same in both installation modes. No skipLibCheck or vendor patch is needed for this Bundler profile. Package server declarations also support strict NodeNext. The complete copied client source and pinned ext-apps implementation declaration graph are scoped to Bundler, not claimed as NodeNext acceptance.

## Wire a real host

Open a **dedicated** SQLite database in your server, construct BlockWorkflowStore, seed server-owned state and registerExtractReviewSaveServer(mcpServer,{store,policyRevision,resolvePrincipal,html,executors}). Supply the built ExtractReviewSaveApp HTML; the helper registers ui://mcpcn/blocks/extract-review-save.html and read/prepare/confirm/cancel tools. Resolve the workspace, actor and block grants from verified transport/server context on **every** call. Tool arguments, metadata and UI consent are not credentials or human attestation. Never use the authored fixed fixture principal for a public server.

In a separate browser entry, import { ExtractReviewSaveApp } from "./extract-review-save" and render it inside MCPCNProvider from ../provider. Its record id comes from the authorized read tool result, or set an explicit id prop. Choose standard-mcp or openai in mcpcn.json; both use the existing explicit adapter. The browser must never import .server.mts, .fixture.mts or .server.test.mts.

Register only trusted synchronous transaction-local SQL executors using the same database. Enforce current business-row revision and principal scope inside each executor, as the fixture does. Real business changes, state, token consumption and audit commit together. Bulk members share one savepoint; any failure rolls back all selected business rows and saves a sanitized failure outcome. This does not atomically send email, charge cards or update external services. Those require your own durable idempotency/outbox/reconciliation.

Review tokens expire after five minutes and bind actor/workspace/block/record/revision/policy/exact terms. Consumed-token replay returns the original receipt without re-execution; current grants are still required. After an uncertain response reload the record/audit. Cancellation revokes pending work and cannot undo committed changes.

Text extraction supports bounded complete UTF-8 .txt/.md documents only, including a preserved BOM. Invoice labels: Supplier:, Total:, Currency:. Contract: Party:, Effective date:, Term:. Resume: Name:, Email:, Experience:. Extract explicitly, review full source/hash/fields, then separately review acceptance. No OCR, PDF or AI provider is supplied.

Full business values, source, arguments, review tokens and audit are app-only metadata. Public output contains deliberate identity/status/revision/receipt only. The app displays complete values, starts every exact review unchecked and requires a fresh read after uncertain mutation.

Styles/tokens are in ../styles.css (copy) or the imported @mcpcn React/theme styles (package). The observed desktop/narrow screenshots and current verification boundary are linked from https://mcpcn-ui.vercel.app/docs/block-recipes. External host certification, public npm publication and production Auth/provider integration remain separate gates.
