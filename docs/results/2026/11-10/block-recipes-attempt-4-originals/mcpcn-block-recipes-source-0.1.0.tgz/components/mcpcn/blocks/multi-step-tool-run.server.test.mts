import test from "node:test";
import { exerciseBlockFixture } from "./multi-step-tool-run.fixture.mjs";
test("multi-step-tool-run persists reviewed changes through the real SDK and SQLite", async () => { await exerciseBlockFixture("multi-step-tool-run"); });
