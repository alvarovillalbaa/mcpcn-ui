"use client";
export { PartialResultViewer } from "./_mcpcn/components";
