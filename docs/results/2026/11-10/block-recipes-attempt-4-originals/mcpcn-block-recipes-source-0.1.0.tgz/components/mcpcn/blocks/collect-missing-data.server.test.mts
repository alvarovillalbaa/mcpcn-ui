import test from "node:test";
import { exerciseBlockFixture } from "./collect-missing-data.fixture.mjs";
test("collect-missing-data persists reviewed changes through the real SDK and SQLite", async () => { await exerciseBlockFixture("collect-missing-data"); });
