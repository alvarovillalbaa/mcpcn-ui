import test from "node:test";
import { exerciseBlockFixture } from "./file-upload-and-extract.fixture.mjs";
test("file-upload-and-extract persists reviewed changes through the real SDK and SQLite", async () => { await exerciseBlockFixture("file-upload-and-extract"); });
