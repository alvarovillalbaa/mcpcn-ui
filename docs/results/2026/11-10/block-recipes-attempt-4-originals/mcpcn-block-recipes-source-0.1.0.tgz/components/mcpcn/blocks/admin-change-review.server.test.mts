import test from "node:test";
import { exerciseBlockFixture } from "./admin-change-review.fixture.mjs";
test("admin-change-review persists reviewed changes through the real SDK and SQLite", async () => { await exerciseBlockFixture("admin-change-review"); });
