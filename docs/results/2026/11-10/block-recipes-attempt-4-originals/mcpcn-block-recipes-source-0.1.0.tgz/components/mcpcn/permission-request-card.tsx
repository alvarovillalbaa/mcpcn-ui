"use client";
export { PermissionRequestCard } from "./_mcpcn/components";
