"use client";
export { Badge } from "./_mcpcn/components";
