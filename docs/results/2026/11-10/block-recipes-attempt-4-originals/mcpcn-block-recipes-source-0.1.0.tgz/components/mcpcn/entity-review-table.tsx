"use client";
export { EntityReviewTable } from "./_mcpcn/components";
