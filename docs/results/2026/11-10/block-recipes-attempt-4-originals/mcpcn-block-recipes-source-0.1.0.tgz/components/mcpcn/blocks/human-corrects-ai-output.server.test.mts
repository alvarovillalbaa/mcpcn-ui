import test from "node:test";
import { exerciseBlockFixture } from "./human-corrects-ai-output.fixture.mjs";
test("human-corrects-ai-output persists reviewed changes through the real SDK and SQLite", async () => { await exerciseBlockFixture("human-corrects-ai-output"); });
