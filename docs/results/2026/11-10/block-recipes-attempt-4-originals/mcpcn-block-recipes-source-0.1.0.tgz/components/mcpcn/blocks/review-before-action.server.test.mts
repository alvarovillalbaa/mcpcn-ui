import test from "node:test";
import { exerciseBlockFixture } from "./review-before-action.fixture.mjs";
test("review-before-action persists reviewed changes through the real SDK and SQLite", async () => { await exerciseBlockFixture("review-before-action"); });
