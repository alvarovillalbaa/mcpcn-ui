import test from "node:test";
import { exerciseBlockFixture } from "./table-bulk-action-review.fixture.mjs";
test("table-bulk-action-review persists reviewed changes through the real SDK and SQLite", async () => { await exerciseBlockFixture("table-bulk-action-review"); });
