"use client";
export { TradeoffPanel } from "./_mcpcn/components";
