"use client";
export { RecordInspector } from "./_mcpcn/components";
