"use client";
export { InlineEditForm } from "./_mcpcn/components";
