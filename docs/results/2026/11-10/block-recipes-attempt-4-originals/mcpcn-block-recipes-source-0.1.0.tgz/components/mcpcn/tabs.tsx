"use client";
export { Tabs } from "./_mcpcn/components";
