"use client";
export { DynamicQuestionFlow } from "./_mcpcn/components";
