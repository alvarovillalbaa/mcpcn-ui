"use client";
export { RankingList } from "./_mcpcn/components";
