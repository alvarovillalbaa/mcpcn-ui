"use client";
export { ConfirmationPanel } from "./_mcpcn/components";
