import { createBlockFixture, blockFixtureResult, BLOCK_FIXTURE_ID } from "../_mcpcn/block-fixtures.mjs";
export { seedBlockFixture, blockFixturePrincipal, blockFixtureExecutors, exerciseBlockFixture } from "../_mcpcn/block-fixtures.mjs";
export const example = createBlockFixture("collect-missing-data");
export const exampleInput = { id: BLOCK_FIXTURE_ID, revision: 1, proposal: example.proposal };
export const exampleResult = blockFixtureResult("collect-missing-data");
