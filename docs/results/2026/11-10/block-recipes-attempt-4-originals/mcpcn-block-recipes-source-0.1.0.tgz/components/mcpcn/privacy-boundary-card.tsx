"use client";
export { PrivacyBoundaryCard } from "./_mcpcn/components";
