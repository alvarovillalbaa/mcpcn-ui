"use client";

import { useEffect, useState, type ReactNode } from "react";
import { AgentAppProvider, OfficialMCPAdapter, type AgentAppAdapter } from "./_mcpcn/runtime";
import "./styles.css";

export function MCPCNProvider({ children }: { children: ReactNode }) {
  const [adapter, setAdapter] = useState<AgentAppAdapter | null>(null);
  useEffect(() => { setAdapter(new OfficialMCPAdapter()); }, []);
  return <div className="mcpcn" data-mcpcn-theme="default">
    {adapter ? <AgentAppProvider adapter={adapter}>{children}</AgentAppProvider>
      : <p role="status" aria-busy="true">Preparing app connection…</p>}
  </div>;
}
