"use client";
export { DataAccessNotice } from "./_mcpcn/components";
