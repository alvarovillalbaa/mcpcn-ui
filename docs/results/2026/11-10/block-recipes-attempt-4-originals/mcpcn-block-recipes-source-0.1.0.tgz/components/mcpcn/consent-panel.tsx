"use client";
export { ConsentPanel } from "./_mcpcn/components";
