# MCPCN block recipes source

Eleven editable blocks, their full UI/server/schema closure, real disposable SQL examples, runnable tests and individual READMEs. Node24.22.2 is required.

Run `npm install --ignore-scripts --no-audit --no-fund`, `npx tsc -p tsconfig.json`, then `node --test checks/blocks/*.server.test.mjs`. `npx vite build` builds the client entry. It intentionally waits for an authorized MCP host; no fake backend is connected. Wire a block using its own .server.mts/.README.md, a caller-opened dedicated SQLite database, verified per-request principals and the matching built app HTML. Keep server/fixture/test modules outside browser imports.

SQL executors are trusted synchronous transaction-local functions, not atomic external service calls. No identity, provider, model, payment or production data is supplied. Authored fixtures use disposable databases only. Source manifest binds all171 exact CLI-installed files to the checked commit. Full copied NodeNext, external hosts, public npm and broad accessibility/device acceptance remain separate gates.
